/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Injectable } from '@nestjs/common';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { v4 as uuidv4 } from 'uuid';
import { FileUpload } from '../../common/interfaces/file-upload.interface';
import { s3Config } from './s3.config';

/**
 * Service for managing file uploads to AWS S3.
 * Handles file uploads using AWS SDK's S3Client.
 */
@Injectable()
export class S3Service {
  private s3: S3Client;

  /**
   * Initializes the S3 client with configuration from environment variables.
   */
  constructor() {
    this.s3 = new S3Client({
      region: s3Config.region,
      credentials: {
        accessKeyId: s3Config.accessKeyId,
        secretAccessKey: s3Config.secretAccessKey,
      },
    });
  }

  /**
   * Uploads a file to AWS S3 bucket and returns the file's URL.
   * The file is uploaded to the 'uploads' directory in the S3 bucket with a unique identifier.
   *
   * @param {FileUpload} file - The file to be uploaded. Should implement the FileUpload interface.
   * @returns {Promise<string>} The URL of the uploaded file.
   * @throws {Error} If the file upload fails.
   */
  async uploadFile(file: FileUpload): Promise<string> {
    const bucketName = process.env.AWS_S3_BUCKET_NAME;

    // Generate a unique key for the file using uuid and original file name
    const key = `uploads/${uuidv4()}-${file.originalname}`;

    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
    });

    // Send the upload command to S3
    await this.s3.send(command);

    // Return the URL of the uploaded file
    return `https://${bucketName}.s3.amazonaws.com/${key}`;
  }
}
