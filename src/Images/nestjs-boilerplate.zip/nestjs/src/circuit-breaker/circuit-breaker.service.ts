import { Injectable } from '@nestjs/common';
import * as CircuitBreaker from 'opossum';
import { Logger, AxiosWrapper, CircuitBreakerWrapper, ApigeeAuthService } from 'nest-common-utilities';


@Injectable()
export class CircuitBreakerService {
    private logger = new Logger(CircuitBreakerService.name);
    private readonly axios: AxiosWrapper;


    private axiosBreaker: CircuitBreaker;


    constructor() {
        const apigeeAuthConfig = new ApigeeAuthService({
            tokenUrl: '',
            clientId: '',
            clientSecret: ''
        })

        // Initialize AxiosWrapper
        this.axios = new AxiosWrapper({
            baseURL: 'http://localhost:4000/health-check', // Change to your actual API URL
            // apigeeAuthService: apigeeAuthConfig
        });
    }

    async safeGetData() {
        const breaker = new CircuitBreakerWrapper(
            () => this.axios.get(), // Axios method
            { timeout: 2000, errorThresholdPercentage: 60 } // Custom CircuitBreaker options
        );
        try {
            const response = await breaker.fire();
            return response.data;
        } catch (error) {
            console.error('Request failed:', error.message);
            throw error; // Handle failure as you want (return fallback, retry, etc.)
        }
    }

    async safePostData(data: any) {
        const breaker = new CircuitBreakerWrapper(
            () => this.axios.post(data),
            { timeout: 3000 }
        );

        try {
            const response = await breaker.fire();
            return response.data;
        } catch (error) {
            console.error('Post request failed:', error.message);
            throw error;
        }
    }
}

