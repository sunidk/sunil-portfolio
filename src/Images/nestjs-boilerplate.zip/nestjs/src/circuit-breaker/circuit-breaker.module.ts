import { Module, OnModuleInit } from '@nestjs/common';
import { CircuitBreakerService } from './circuit-breaker.service';

@Module({
  imports: [],
  providers: [CircuitBreakerService],
  exports: [CircuitBreakerService],
})
export class CircuitBreakerModule implements OnModuleInit {
  constructor(private cb: CircuitBreakerService) { }

  async onModuleInit() {
    console.log('PSQL Initiated');
    const data = await this.cb.safeGetData();
    console.log("data::", data);
  }
}
