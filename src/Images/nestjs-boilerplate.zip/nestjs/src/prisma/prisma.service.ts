// /**
//  @file        <file name>
//  @description  <description>
//  @author      <Your Name>
//  @created     <YYYY-MM-DD>
// **/

import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { setEncryptedFields, createExtendedPrisma } from 'nest-common-utilities';
import encryptedFields from '../config/prisma.config';

@Injectable()
export class PrismaService extends PrismaClient {
  constructor() {
    // Call parent constructor first
    super();

    // Set encrypted field config from host app
    setEncryptedFields(encryptedFields);

    // Apply Prisma extensions to `this`
    const extended = createExtendedPrisma(this);

    // Copy properties from extended back into `this`
    Object.assign(this, extended);
  }
}