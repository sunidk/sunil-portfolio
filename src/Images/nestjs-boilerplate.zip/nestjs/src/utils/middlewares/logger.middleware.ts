/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/

import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { Logger } from 'nest-common-utilities';


/**
 * LoggerMiddleware is responsible for logging the HTTP method, URL, and timestamp of each incoming request.
 * This middleware logs the request details to the console before passing control to the next handler in the pipeline.
 */
@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  private logger = new Logger(LoggerMiddleware.name);

  constructor() { }
  /**
   * Intercepts incoming requests, logs their method, URL, and timestamp, and then proceeds to the next middleware or route handler.
   * 
   * @param req - The incoming request object.
   * @param res - The response object.
   * @param next - The callback function to pass control to the next middleware or route handler.
   */
  use(req: Request, res: Response, next: NextFunction) {
    const { method, originalUrl } = req;
    const time = new Date().toISOString();

    // Log the HTTP method, URL, and timestamp
    this.logger.info(`[${time}] ${method} ${originalUrl}`);

    // Proceed to the next middleware or route handler
    next();
  }
}
