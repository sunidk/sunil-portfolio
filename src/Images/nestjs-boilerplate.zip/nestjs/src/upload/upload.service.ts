/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/

import { Injectable } from '@nestjs/common';
import { S3Service } from '../aws/s3/s3.service';
import { FileUpload } from '../common/interfaces/file-upload.interface';

/**
 * UploadService class to manage file upload functionality.
 * This service delegates the actual file upload process to the S3Service.
 */
@Injectable()
export class UploadService {
  /**
   * Initializes the UploadService with the S3Service dependency.
   * 
   * @param {S3Service} s3Service - The service responsible for handling interactions with AWS S3 for file uploads.
   */
  constructor(private readonly s3Service: S3Service) {}

  /**
   * Handles the file upload process by delegating to the S3Service's uploadFile method.
   * 
   * @param {FileUpload} file - The file to be uploaded, implementing the FileUpload interface.
   * @returns {Promise<string>} - The URL of the uploaded file in the S3 bucket.
   */
  async uploadFile(file: FileUpload): Promise<string> {
    return this.s3Service.uploadFile(file);
  }
}
