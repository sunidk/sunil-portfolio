/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import {
  Controller,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { UploadService } from './upload.service';
import { FileUpload } from '../common/interfaces/file-upload.interface';

/**
 * UploadController class to manage file uploads.
 * This controller receives file upload requests and delegates the file upload process to the UploadService.
 */
@Controller('upload')
export class UploadController {
  /**
   * Initializes the UploadController with the UploadService dependency.
   * 
   * @param {UploadService} uploadService - The service responsible for handling file upload operations.
   */
  constructor(private readonly uploadService: UploadService) {}

  /**
   * Endpoint to handle file uploads. 
   * Uses the FileInterceptor to handle the file before delegating the upload task to the UploadService.
   * 
   * @param {FileUpload} file - The uploaded file to be processed.
   * @returns {Promise<string>} - A promise that resolves to the URL of the uploaded file in the S3 bucket.
   */
  @Post()
  @UseInterceptors(FileInterceptor('file'))
  async upload(@UploadedFile() file: FileUpload): Promise<string> {
    return this.uploadService.uploadFile(file);
  }
}
