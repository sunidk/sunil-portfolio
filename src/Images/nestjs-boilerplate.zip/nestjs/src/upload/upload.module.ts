/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Module } from '@nestjs/common';
import { UploadController } from './upload.controller';
import { UploadService } from './upload.service';
import { S3Module } from '../aws/s3/s3.module';

/**
 *
 */
@Module({
  imports: [S3Module],
  controllers: [UploadController],
  providers: [UploadService],
})
export class UploadModule {}
