import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { MicroserviceHealthService } from './microservice.service';
import { generateClientRegistrations } from './microservice.registration';

@Module({
  imports: [
    ClientsModule.register(generateClientRegistrations()),
  ],
  providers: [MicroserviceHealthService],
  exports: [ClientsModule, MicroserviceHealthService],
})
export class AuthClientModule { }
