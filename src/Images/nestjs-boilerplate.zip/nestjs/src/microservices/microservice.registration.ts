import { Transport, ClientProviderOptions } from '@nestjs/microservices';
import { MICROSERVICE_CONFIGS } from './microservices.config';

export const generateClientRegistrations = (): ClientProviderOptions[] =>
  MICROSERVICE_CONFIGS.map(({ name, host, port }) => ({
    name,
    transport: Transport.TCP,
    options: { host, port },
  }));
