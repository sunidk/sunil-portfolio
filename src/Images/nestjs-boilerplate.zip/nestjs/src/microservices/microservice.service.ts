import { Injectable } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { ClientProxy } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';
import { Logger } from 'nest-common-utilities';


@Injectable()
export class MicroserviceHealthService {
    private logger = new Logger(MicroserviceHealthService.name);

    constructor(
        private moduleRef: ModuleRef,
    ) { }

    /**
     * Checks if a microservice registered with the given token is available.
     * @param token The DI token used to register the microservice (e.g. 'AUTH_SERVICE')
     */
    async isServiceAvailable(token: string): Promise<boolean> {
        try {
            const client: ClientProxy = this.moduleRef.get<ClientProxy>(token, { strict: false });

            const result = await client.send({ cmd: 'ping' }, {});
            const response = await firstValueFrom(result);

            this.logger.info(`Response from microservice ${token}:`, response);
            return response === 'pong';
        } catch (error) {
            this.logger.error(`Could not contact microservice ${token}:`, error.message);
            return false;
        }
    }

    /**
     * Checks multiple services at once.
     * @param tokens List of service tokens to check
     */
    async checkMultipleServices(tokens: string[]): Promise<Record<string, boolean>> {
        const statuses: Record<string, boolean> = {};
        for (const token of tokens) {
            statuses[token] = await this.isServiceAvailable(token);
        }
        return statuses;
    }
}
