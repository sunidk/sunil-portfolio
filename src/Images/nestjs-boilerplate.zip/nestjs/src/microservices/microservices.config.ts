export const MICROSERVICE_CONFIGS = [
    {
        name: 'AUTH_SERVICE',
        host: 'localhost',
        port: 3001,
    },
];
