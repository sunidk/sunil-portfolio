/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Role as PrismaRole } from '@prisma/client';
import { Exclude, Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

/**
 *
 */
export class GetUserDto {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({ example: 'Roshan', description: 'Name of the user' })
  name: string;

  @Expose()
  @ApiProperty({ example: 'roshan@example.com', description: 'Email address' })
  email: string;

  @Exclude()
  hashemail: string;

  @Expose()
  @ApiProperty({ example: 'user|admin', description: 'User Role' })
  role: PrismaRole;

  @Exclude()
  @ApiProperty({ example: 'Roshan@123', description: 'Password' })
  password: string;
}
