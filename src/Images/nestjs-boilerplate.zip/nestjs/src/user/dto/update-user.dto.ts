/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import {
  IsString,
  IsEmail,
  MinLength,
  IsOptional,
  IsEnum,
} from 'class-validator';
import { Role as PrismaRole } from '@prisma/client';
import { ApiProperty } from '@nestjs/swagger';

/**
 *
 */
export class UpdateUserDto {
  @IsOptional()
  @IsString()
  @MinLength(2, { message: 'Name must be at least 2 characters long' })
  @ApiProperty({ example: 'Roshan', description: 'Name of the user' })
  name?: string;

  @IsOptional()
  @IsEmail({}, { message: 'Invalid email format' })
  @ApiProperty({ example: 'roshan@example.com', description: 'Email address' })
  email?: string;

  @IsEnum(PrismaRole)
  @ApiProperty({ example: 'user|admin', description: 'User Role' })
  role: PrismaRole;
}
