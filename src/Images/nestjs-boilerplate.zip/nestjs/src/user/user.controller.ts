/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/

import {
  Body,
  Controller,
  Get,
  Put,
  Param,
  Post,
  UsePipes,
  ValidationPipe,
  UseGuards,
  Req,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { GetUserDto } from './dto/get-user.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role as PrismaRole } from '@prisma/client';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CasbinGuard } from '../auth/guards/casbin.guard';
import { Action, Resource } from '../common/decorators/casbin-policy.decorator';
import { Logger } from 'nest-common-utilities';


/**
 *
 */
@Controller('user')
@Resource('user')
export class UserController {
  private logger = new Logger(UserController.name);

  /**
   * Constructor for initializing the class with the provided user service and logger.
   *
   * @param {UserService} usersService - The service used to interact with user-related data.
   * @param {PinoLogger} logger - The logger instance used for logging activities.
  */
  constructor(
    private readonly usersService: UserService,
  ) { }


  /**
   * Creates a new user based on the provided user data.
   * 
   * @param {CreateUserDto} createUserDto - The data transfer object containing the information for creating a new user.
   * @returns {Promise<GetUserDto>} The created user information.
   */
  @Post()
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
  )
  @ApiOperation({ summary: 'Create user' })
  @ApiResponse({ status: 200, description: 'The user has been created.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  create(@Body() createUserDto: CreateUserDto): Promise<GetUserDto> {
    return this.usersService.create(createUserDto);
  }

  /**
   * Updates an existing user's information based on the provided ID and update data.
   *
   * @param {number} id - The ID of the user to be updated.
   * @param {UpdateUserDto} updateUserDto - The data transfer object containing the updated user information.
   * @returns {Promise<GetUserDto>} The updated user information.
   */
  @Put(':id')
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
  )
  @ApiOperation({ summary: 'Update user' })
  @ApiResponse({ status: 200, description: 'The user has been updated.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  update(
    @Param('id') id: number,
    @Body() updateUserDto: UpdateUserDto,
  ): Promise<GetUserDto> {
    this.logger.info('User Updated::', updateUserDto);
    return this.usersService.update(+id, updateUserDto);
  }

  /**
   * Retrieves a user by their ID.
   * 
   * @param {number} id - The ID of the user to retrieve.
   * @returns {Promise<GetUserDto>} The user's information.
   */
  @Get(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(PrismaRole.user)
  @UsePipes(new ValidationPipe({ transform: true }))
  @ApiOperation({ summary: 'Get user by ID' })
  @ApiResponse({ status: 200, description: 'Success.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  findOne(
    @Param('id') id: number,
  ): Promise<GetUserDto> {
    return this.usersService.findOne(+id);
  }

  /**
   * Retrieves a list of all users.
   *
   * @returns {Promise<GetUserDto[]>} An array of user information.
   */
  @UseGuards(JwtAuthGuard, CasbinGuard)
  @Action('read')
  @ApiOperation({ summary: 'Get all users' })
  @ApiResponse({ status: 200, description: 'Success.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  @Get()
  findAll(): Promise<GetUserDto[]> {
    // this.logger.info("in find all::")
    return this.usersService.findAll();
  }
}
