/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { GetUserDto } from './dto/get-user.dto';
import * as bcrypt from 'bcrypt';
import { plainToInstance } from 'class-transformer';

/**
 * Service for handling user operations.
 */
@Injectable()
export class UserService {
  /**
   * Initializes the class with the PrismaService instance.
   *
   * @param {PrismaService} prisma - The PrismaService instance used for interacting with the database.
   */
  constructor(private prisma: PrismaService) { }
  private readonly saltRounds = 10;


  /**
   * Creates a new user based on the provided user data.
   *
   * @param {CreateUserDto} createUserDto - The data transfer object containing the user information to be created.
   * @returns {Promise<GetUserDto>} A promise that resolves to the created user’s data.
   */
  async create(createUserDto: CreateUserDto): Promise<GetUserDto> {
    const { name, email, password, role } = createUserDto;
    const hashedPassword = await bcrypt.hash(password, this.saltRounds);

    const user = await this.prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        role: role,
        hashemail: email
      },
    });
    return plainToInstance(GetUserDto, user);
  }



  /**
   * Updates the user with the given ID using the provided update data.
   *
   * @param {number} id - The ID of the user to update.
   * @param {UpdateUserDto} updateUserDto - The data transfer object containing the updated user information.
   * @returns {Promise<GetUserDto>} A promise that resolves to the updated user's data.
   */
  async update(id: number, updateUserDto: UpdateUserDto): Promise<GetUserDto> {
    const user = await this.prisma.user.update({
      where: { id },
      data: updateUserDto,
    });
    return plainToInstance(GetUserDto, user);
  }


  /**
   * Retrieves the user with the specified ID.
   *
   * @param {number} id - The ID of the user to retrieve.
   * @returns {Promise<GetUserDto>} A promise that resolves to the user’s data.
   */
  async findOne(id: number): Promise<GetUserDto> {
    const user = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return plainToInstance(GetUserDto, user);
  }

  /**
   * Retrieves a user by their email address.
   *
   * @param {CreateUserDto['email']} email - The email address of the user to retrieve.
   * @returns {Promise<GetUserDto | null>} A promise that resolves to the user's data if found, or null if no user is found.
   */
  async findByEmail(email: CreateUserDto['email']): Promise<GetUserDto | null> {
    try {
      const user = await this.prisma.user.findUnique({
        where: { email },
      });
      if (!user) {
        return null;
      }

      return user;
    } catch (error) {
      return null;
    }
  }

  /**
   * Retrieves a list of all users.
   *
   * @returns {Promise<GetUserDto[]>} A promise that resolves to an array of user data.
   */
  async findAll(): Promise<GetUserDto[]> {
    const user = await this.prisma.user.findMany({});

    return plainToInstance(GetUserDto, user);
  }
}
