/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
export interface IPaginationOptions {
  page: number;
  limit: number;
}
