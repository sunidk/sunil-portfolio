/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { NestFactory, Reflector } from '@nestjs/core';
import { ClassSerializerInterceptor } from '@nestjs/common';
import { AppModule } from './app.module';
import helmet from 'helmet';
import { setupSwagger } from './common/swagger/swagger.config';
import { MicroserviceHealthService } from './microservices/microservice.service'
import { MICROSERVICE_CONFIGS } from './microservices/microservices.config';
import { Logger } from 'nest-common-utilities';
import { HttpExceptionFilter, ResponseInterceptor, DecryptMiddleware, EncryptInterceptor } from 'nest-common-utilities';

/**
 * The main function that bootstraps the NestJS application, sets up global middleware,
 * exception filters, interceptors, CORS, security headers, and Swagger documentation.
 * 
 * @returns {Promise<void>} A promise that resolves once the application has started.
 */
async function bootstrap(): Promise<void> {
  // Create a new NestJS application
  const app = await NestFactory.create(AppModule);

  const logger = new Logger('app');

  // Apply global filters to handle HTTP exceptions
  app.useGlobalFilters(new HttpExceptionFilter());

  // Enable Cross-Origin Resource Sharing (CORS) for the application
  app.enableCors();

  // Apply security headers using helmet middleware
  app.use(helmet());

  // Set up global interceptors for serialization and response encryption
  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));
  app.useGlobalInterceptors(new ResponseInterceptor());

  if (process.env.NODE_ENV != "prod") {
    // Set up Swagger API documentation
    setupSwagger(app);
  }

  // const tokens = MICROSERVICE_CONFIGS.map(cfg => cfg.name);
  // const healthService = app.get(MicroserviceHealthService);
  // const statuses = await healthService.checkMultipleServices(tokens);

  // const allUp = Object.values(statuses).every(status => status === true);
  // if (!allUp) {
  //   logger.error(' One or more microservices are not available:', statuses);
  //   process.exit(1);
  // }


  // Start the application on the specified port or fallback to 3000
  await app.listen(process.env.PORT ?? 3000, () => {
    logger.info(`Server started on port: ${process.env.PORT}`);
  });
}

// Call the bootstrap function to start the application
bootstrap();
