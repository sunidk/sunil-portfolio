/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Module } from '@nestjs/common';
import { CryptoapiController } from './cryptoapi.controller';

/**
 *
 */
@Module({
  controllers: [CryptoapiController],
})
export class CryptoapiModule {}
