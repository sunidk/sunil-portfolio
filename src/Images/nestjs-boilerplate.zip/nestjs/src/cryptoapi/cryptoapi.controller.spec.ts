/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Test, TestingModule } from '@nestjs/testing';
import { CryptoapiController } from './cryptoapi.controller';

describe('CryptoapiController', () => {
  let controller: CryptoapiController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CryptoapiController],
    }).compile();

    controller = module.get<CryptoapiController>(CryptoapiController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
