/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Controller, Post, Body } from '@nestjs/common';
import { encrypt, decrypt } from 'nest-common-utilities';

/**
 * Controller that provides cryptographic services like encrypting and decrypting data.
 * Uses utility functions `encrypt` and `decrypt` to perform the operations.
 */
@Controller('cryptoapi')
export class CryptoapiController {
  /**
   * Encrypts the provided data in the request body.
   * 
   * @param {any} body - The data to be encrypted. It will be stringified before encryption.
   * @returns {object} An object containing the encrypted data.
   */
  @Post('encrypt')
  encryptData(@Body() body: any) {
    // Stringify the body data and encrypt it
    const plaintext = JSON.stringify(body);
    const encrypted = encrypt(plaintext);
    return { data: encrypted };
  }

  /**
   * Decrypts the provided encrypted data.
   *
   * @param {object} body - The body containing the encrypted data.
   * @param {string} body.data - The encrypted string to be decrypted.
   * @returns {string} The decrypted data.
   */
  @Post('decrypt')
  decryptData(@Body() body: { data: string }) {
    // Decrypt the provided encrypted data
    const decrypted = decrypt(body.data);
    return decrypted;
  }
}
