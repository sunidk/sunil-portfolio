/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Injectable } from '@nestjs/common';

/**
 * Provides core application logic and utility methods used throughout the app.
 */
@Injectable()
export class AppService {}
