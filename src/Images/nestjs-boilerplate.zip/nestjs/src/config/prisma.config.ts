const encryptedFields = {
    user: ['hashemail'],
};

export default encryptedFields;
