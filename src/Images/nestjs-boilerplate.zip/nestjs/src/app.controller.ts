/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';


/**
 * This controller handles the core routes of the application.
 * It may include routes for health checks, the home page, or other basic functionality.
 */
@Controller()
export class AppController {
  /**
 * Initializes the controller with the provided AppService instance.
 *
 * @param {AppService} appService - The service used for handling application logic.
 */
  constructor(private readonly appService: AppService) {}

}
