/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { ApiProperty } from '@nestjs/swagger';

/**
 *
 */
export class LoginResponseDto {
  @ApiProperty({ example: 'asdvbregwevklmerger', description: 'Access token' })
  accessToken: string;

  @ApiProperty({ example: 'asdvbregwevklmerger', description: 'Refresh token' })
  refreshToken: string;
}
