/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { IsEmail, IsNotEmpty } from 'class-validator';
import { Transform } from 'class-transformer';
import { lowerCaseTransformer } from '../../common/transformers/lower-case.transformer';
import { ApiProperty } from '@nestjs/swagger';

/**
 *
 */
export class AuthEmailLoginDto {
  @Transform(lowerCaseTransformer)
  @IsEmail()
  @IsNotEmpty()
  @ApiProperty({ example: 'roshan@example.com', description: 'Email address' })
  email: string;

  @IsNotEmpty()
  @ApiProperty({ example: 'Roshan@123', description: 'Password' })
  password: string;
}
