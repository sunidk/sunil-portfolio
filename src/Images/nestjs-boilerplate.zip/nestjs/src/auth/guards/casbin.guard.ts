/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import {
  CanActivate,
  ExecutionContext,
  Injectable,
  ForbiddenException,
  Inject
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ClientProxy } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';
import { Logger } from 'nest-common-utilities';



/**
 * Guard that integrates Casbin for fine-grained, role-based access control.
 * It checks if a user has permission to access a route based on defined action and resource metadata.
 */
@Injectable()
export class CasbinGuard implements CanActivate {
  private logger = new Logger(CasbinGuard.name);

  /**
   * Constructs the guard with necessary dependencies.
   *
   * @param {Reflector} reflector - Used to retrieve metadata (e.g., action, resource) from route handlers or controllers.
   * @param {CasbinService} casbinService - Service used to evaluate permissions through Casbin.
   */
  constructor(
    private reflector: Reflector,
    @Inject('AUTH_SERVICE') private readonly authClient: ClientProxy
  ) {
  }

  /**
   * Determines whether the current user has permission to access the route.
   *
   * @param {ExecutionContext} context - Provides details about the current request pipeline.
   * @returns {Promise<boolean>} Whether the request is allowed based on Casbin policies.
   * @throws {ForbiddenException} If permission is denied.
   */
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    const handler = context.getHandler();

    const action =
      this.reflector.get<string>('action', handler) ??
      this.reflector.get<string>('action', context.getClass());

    const resource =
      this.reflector.get<string>('resource', handler) ??
      this.reflector.get<string>('resource', context.getClass());

    const result = this.authClient.send<boolean>(
      { cmd: 'check-permission' },
      { subject: user.role, resource, action },
    );

    const allowed = await firstValueFrom(result);
    this.logger.info(`allowed:: ${allowed}`);

    if (!allowed) {
      throw new ForbiddenException('Access Denied');
    }

    return true;
  }
}
