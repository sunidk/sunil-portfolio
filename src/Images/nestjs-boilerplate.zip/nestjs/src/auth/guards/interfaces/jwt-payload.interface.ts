/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
export interface JwtPayload {
  name: string;
  email: string;
  role: string;
}
