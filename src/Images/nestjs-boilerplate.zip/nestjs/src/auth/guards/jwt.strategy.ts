/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy, StrategyOptions } from 'passport-jwt';
import { JwtPayload } from './interfaces/jwt-payload.interface';
import { Request } from 'express';

/**
 * Passport strategy for validating JWT tokens.
 * Extracts the token from the Authorization header and verifies its signature and payload.
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  /**
   * Initializes the JWT strategy with extraction and verification options.
   * Uses the secret defined in the environment or falls back to a default.
   */
  constructor() {
    const jwtFromRequest: (req: Request) => string | null =
      ExtractJwt.fromAuthHeaderAsBearerToken() as (
        req: Request,
      ) => string | null;

    const jwtOptions: StrategyOptions = {
      jwtFromRequest,
      secretOrKey: process.env.JWT_SECRET_KEY || 'niveusHDFC',
    };

    super(jwtOptions);
  }

  /**
   * Validates the decoded JWT payload.
   * This method is called automatically by Passport once the token is verified.
   *
   * @param {JwtPayload} payload - The decoded JWT payload containing user information.
   * @returns {{ email: string; name: string; role: string }} The user object to attach to the request.
   */
  validate(payload: JwtPayload) {
    return { email: payload.email, name: payload.name, role: payload.role };
  }
}
