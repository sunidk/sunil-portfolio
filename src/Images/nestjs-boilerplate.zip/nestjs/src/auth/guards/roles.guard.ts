/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../../common/decorators/roles.decorator';
import { Role as PrismaRole } from '@prisma/client';
import { Logger } from 'nest-common-utilities';


/**
 * Guard that enforces role-based access control by validating user roles
 * against metadata defined via the `@Roles()` decorator.
 */
@Injectable()
export class RolesGuard implements CanActivate {
  private logger = new Logger(RolesGuard.name);

  /**
   * Initializes the guard with NestJS's Reflector to access route metadata.
   *
   * @param {Reflector} reflector - Used to retrieve role metadata from routes and controllers.
   */
  constructor(
    private reflector: Reflector,
  ) { }

  /**
   * Checks whether the current user has any of the roles required for this route.
   *
   * @param {ExecutionContext} context - Provides access to request and route information.
   * @returns {boolean} True if the user is authorized; otherwise throws a ForbiddenException.
   * @throws {ForbiddenException} If the user role is missing or not allowed.
   */
  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<PrismaRole[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    const { user } = context.switchToHttp().getRequest();
    this.logger.info('Role Guard::', user);

    if (!user || !user.role) {
      throw new ForbiddenException({
        statusCode: 403,
        message: 'User role not found',
        error: 'Forbidden',
      });
    }

    const hasRole = requiredRoles.includes(user.role);
    if (!hasRole) {
      throw new ForbiddenException({
        statusCode: 403,
        message: `User role ${user.role} does not have access to this resource`,
        error: 'Forbidden',
      });
    }

    return hasRole;
  }
}
