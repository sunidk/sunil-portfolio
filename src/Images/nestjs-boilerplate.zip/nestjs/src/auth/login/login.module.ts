/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Module } from '@nestjs/common';
import { LoginController } from './login.controller';
import { LoginService } from './login.service';
import { UserModule } from '../../user/user.module';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from '../guards/jwt.strategy';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { PassportModule } from '@nestjs/passport';

/**
 *
 */
@Module({
  imports: [
    UserModule,
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      secret: process.env.JWT_SECRET_KEY || 'niveusHDFC', // Secret for signing
      signOptions: { expiresIn: '15m' }, // Optional expiration time
    }),
    LoginModule,
  ],
  controllers: [LoginController],
  providers: [LoginService, JwtStrategy, JwtAuthGuard],
  exports: [LoginService, JwtAuthGuard],
})
export class LoginModule { }
