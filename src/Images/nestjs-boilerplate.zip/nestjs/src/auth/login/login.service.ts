/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Injectable } from '@nestjs/common';
import { AuthEmailLoginDto } from '../dto/auth-email-login.dto';
import { LoginResponseDto } from '../dto/login-response.dto';
import { GetUserDto } from '../../user/dto/get-user.dto';
import { UserService } from '../../user/user.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { Logger } from 'nest-common-utilities';


/**
 * Service responsible for user authentication logic such as validating credentials,
 * generating JWT tokens, and refreshing access tokens.
 */
@Injectable()
export class LoginService {
  private logger = new Logger(LoginService.name);

  /**
   * Initializes the LoginService with user and JWT dependencies.
   *
   * @param {UserService} usersService - Service to retrieve user data from the database.
   * @param {JwtService} jwtService - Service for signing and verifying JWT tokens.
   */
  constructor(
    private readonly usersService: UserService,
    private jwtService: JwtService,
  ) { }

  /**
   * Validates the provided email and password credentials.
   *
   * @param {AuthEmailLoginDto} loginDto - DTO containing the email and password to validate.
   * @returns {Promise<GetUserDto | null>} The user if credentials are valid; otherwise, null.
   */
  async validateUser(loginDto: AuthEmailLoginDto): Promise<GetUserDto | null> {
    const user = await this.usersService.findByEmail(loginDto.email);
    if (user && (await bcrypt.compare(loginDto.password, user.password))) {
      return user;
    }
    return null;
  }

  /**
   * Generates JWT access and refresh tokens for a valid user.
   *
   * @param {GetUserDto} user - The authenticated user.
   * @returns {LoginResponseDto} Object containing signed access and refresh tokens.
   */
  login(user: GetUserDto): LoginResponseDto {
    const payload = { email: user.email, name: user.name, role: user.role };
    return {
      accessToken: this.jwtService.sign(payload),
      refreshToken: this.jwtService.sign(payload, { expiresIn: '7d' }),
    };
  }

  /**
   * Refreshes the access token using a valid refresh token.
   *
   * @param {string} token - The refresh token provided by the client.
   * @returns {string} A new access token.
   * @throws {Error} If the token is invalid or expired.
   */
  refreshToken(token: string): string {
    try {
      const decoded = this.jwtService.verify(token);
      return this.jwtService.sign({
        email: decoded.email,
        name: decoded.name,
        role: decoded.role,
      });
    } catch (error) {
      this.logger.error(error);
      throw new Error('Invalid refresh token');
    }
  }
}
