/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import {
  Controller,
  Post,
  Body,
  UsePipes,
  ValidationPipe,
  Req,
} from '@nestjs/common';
import { AuthEmailLoginDto } from '../dto/auth-email-login.dto';
import { LoginResponseDto } from '../dto/login-response.dto';
import { LoginService } from './login.service';
import { Logger } from 'nest-common-utilities';



/**
 * Controller for managing user authentication actions such as login and refresh token.
 */
@Controller('auth')
export class LoginController {
  private logger = new Logger(LoginController.name);

  /**
   * Injects the LoginService responsible for authentication logic.
   *
   * @param {LoginService} loginService - The service that handles validation and token operations.
   */
  constructor(
    private readonly loginService: LoginService
  ) {
  }

  /**
   * Authenticates a user via email and password.
   * Validates the credentials and returns an access/refresh token pair.
   *
   * @param {AuthEmailLoginDto} loginDto - The login DTO containing email and password.
   * @returns {Promise<LoginResponseDto>} A promise that resolves to the JWT access and refresh tokens.
   * @throws {Error} If credentials are invalid.
   */
  @Post('login')
  @UsePipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
  )
  public async login(
    @Body() loginDto: AuthEmailLoginDto,
  ): Promise<LoginResponseDto> {
    this.logger.info(`info logger login ${loginDto}`, loginDto)
    const user = await this.loginService.validateUser(loginDto);
    if (!user) {
      throw new Error('Invalid credentials');
    }
    return this.loginService.login(user);
  }

  /**
   * Refreshes an access token using a valid refresh token.
   *
   * @param {string} refreshToken - The refresh token provided by the client.
   * @returns {string} A new access/refresh token pair.
   */
  @Post('refresh')
  refresh(@Body('refreshToken') refreshToken: string): string {
    return this.loginService.refreshToken(refreshToken);
  }
}
