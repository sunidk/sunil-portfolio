/**
 @file        <file name>
 @description  <description>
 @author      <Your Name>
 @created     <YYYY-MM-DD>
**/
import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { PrismaModule } from './prisma/prisma.module';
import { LoginModule } from './auth/login/login.module';
import { LoggerMiddleware } from './utils/middlewares/logger.middleware';
import { HealthCheckModule } from './health-check/health-check.module';
import { S3Module } from './aws/s3/s3.module';
import { UploadModule } from './upload/upload.module';
import { ConfigModule } from '@nestjs/config';
import { CryptoapiModule } from './cryptoapi/cryptoapi.module';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { CircuitBreakerModule } from './circuit-breaker/circuit-breaker.module';
import { AuthClientModule } from './microservices/microservice.module'
import { TraceIdMiddleware } from 'nest-common-utilities';


/**
 * The root application module that imports and configures all feature modules,
 * global services, and guards for the application.
 */
@Module({
  imports: [
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 5,
      },
    ]),
    ConfigModule.forRoot({ isGlobal: true }),
    UserModule,
    PrismaModule,
    LoginModule,
    HealthCheckModule,
    S3Module,
    UploadModule,
    CryptoapiModule,
    CircuitBreakerModule,
    AuthClientModule
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule implements NestModule {
  /**
   * Configures middleware for the application.
   *
   * @param {MiddlewareConsumer} consumer - Provides methods to apply middleware to controllers or routes.
   */
  configure(consumer: MiddlewareConsumer) {
    // Apply the logger middleware globally (to all routes)
    consumer.apply(TraceIdMiddleware).forRoutes('*');
    consumer.apply(LoggerMiddleware).forRoutes('*');
  }
}
